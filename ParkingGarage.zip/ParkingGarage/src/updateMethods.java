/*
 * The updateMethods interface contains a shareable method updateEventStatus to update Vehicles and ParkingSpots.
 */
public interface updateMethods {
	
	public void updateEventStatus();

}
